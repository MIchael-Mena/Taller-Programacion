defmodule Ledger do
  @moduledoc """
  Documentation for `Ledger`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> Ledger.hello()
      :world

  """
  def hello do
    :world
  end
end
