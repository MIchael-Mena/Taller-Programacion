# Instrucciones para Generar el Ejecutable

## ⚠️ Importante: El ejecutable NO está incluido en esta entrega

Para reducir el tamaño del archivo ZIP (de 2.4 MB a ~200 KB), el ejecutable 
`ledger` NO está incluido. Los evaluadores deben generarlo localmente.

## Pasos para generar el ejecutable:

```bash
# 1. Instalar dependencias
mix deps.get

# 2. Compilar el proyecto
mix compile

# 3. Generar el ejecutable escript
mix escript.build
```

Esto creará el archivo `ledger` (ejecutable) en el directorio raíz del proyecto.

## Verificar que funciona:

```bash
./ledger --help
```

Deberías ver el menú de ayuda con todos los comandos disponibles.

---

**Tiempo estimado:** < 1 minuto (después de tener Elixir y dependencias instaladas)
